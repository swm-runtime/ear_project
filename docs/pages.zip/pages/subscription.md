# 구독 · 인앱 결제 기능 명세서

> 연결 PRD: FR-28, FR-30, FR-31 / 제약 8.2 / 사용자흐름 5.4

## 1. 목적 & 연결

3티어 구독 상태를 관리하고 기능 접근을 분기한다. 결제는 전 과정이 스토어 인앱 결제에 종속되므로(PRD 8.2), 서버는 스토어 영수증을 진실의 원천으로 삼는다.

- PRD FR-28 (P0) 3티어 구독 상태 관리 및 기능 접근 분기
- PRD FR-30 (P0) 인앱 결제, 결제 완료 시 즉시 티어 반영
- PRD FR-31 (P0) 요금제 변경·해지, 해지 시 만료일까지 혜택 유지
- PRD 8.2 의존성 — 스토어 정책·수수료 종속

> **인앱 결제는 스토어 심사·테스트 계정 준비에 시간이 오래 걸리므로 다른 화면 명세와 병행해 즉시 착수한다** (`next_doing.md` 1장 4번).

## 2. 진입 조건

- 페이월 바텀시트의 [구독하기]
- 설정 > 구독 관리
- 온보딩 완료 후 구독 안내(선택 노출)
- 앱 실행 시 **구독 상태 동기화**는 사용자 조작 없이 자동 수행

## 3. 입력값

| 값 | 출처 | 필수 |
|---|---|---|
| plan_id / store_product_id | 서버 요금제 목록 | 필수 |
| platform | ios / android | 필수 |
| purchase_receipt / purchase_token | 스토어 SDK | 필수(검증 시) |
| entry_point | paywall / settings / onboarding | 선택(분석용) |

## 4. 처리 로직

### 4.1 티어 정의 및 기능 분기 (FR-28)

| 티어 | 일 재생 한도 | 드립 | 광고 | 오프라인 저장 |
|---|---|---|---|---|
| free | 2편 | 없음 | 있음 | 불가 |
| light | 서버 설정값 | 있음 | 없음 | 미정 |
| daily | 서버 설정값 | 있음 | 없음 | 미정 |
| pro | 무제한 | 있음 | 없음 | 가능 |

- **모든 수치는 서버 설정값으로 관리한다.** 시범 운영 후 확정(PRD 4.1)되므로 앱 배포 없이 조정 가능해야 한다.
- 클라이언트는 서버가 내려주는 `entitlements` 객체로 기능을 분기한다. 티어명을 클라이언트에 하드코딩하지 않는다.

```
entitlements {
  daily_play_limit: int | null      // null = 무제한
  drip_enabled: boolean
  ads_enabled: boolean
  offline_download_enabled: boolean
}
```

### 4.2 구매 흐름 (FR-30)

1. 서버에서 요금제 목록 조회 → 스토어 SDK로 상품 정보(현지 가격) 조회 → 병합해 노출
2. [구독하기] 탭 → 서버에 `purchase_intent` 생성(멱등키 발급)
3. 스토어 결제 시트 호출
4. 결제 성공 → 클라이언트가 영수증/구매 토큰을 서버로 전송
5. **서버가 스토어 API로 영수증 검증** — 클라이언트 응답을 신뢰하지 않는다
6. 검증 성공 → `Subscription` 생성/갱신, `User.tier` 즉시 반영
7. 클라이언트에 갱신된 `entitlements` 반환 → 즉시 UI 반영
8. 스토어 트랜잭션 `finish` 처리 (서버 검증 성공 후에만)

### 4.3 구독 상태 동기화

- **서버 알림(S2S)이 진실의 원천**: App Store Server Notifications V2 / Google Play Real-time Developer Notifications를 수신해 갱신·해지·환불·유예를 반영한다.
- 클라이언트는 보조적으로 앱 실행 시·포그라운드 복귀 시 `GET /subscription`으로 상태를 동기화한다.
- 만료 판정은 서버의 `expires_at` 기준. 클라이언트 시각을 신뢰하지 않는다.

### 4.4 요금제 변경 (FR-31)

- **업그레이드**(예: light → pro): 스토어 업그레이드 플로우 사용. 즉시 적용 + 잔여 기간 비례 정산은 스토어 정책을 따른다.
- **다운그레이드**(예: pro → light): 현재 결제 주기 만료 시점에 적용. 만료 전까지는 기존 혜택 유지.
- 변경 화면에서 "언제부터 적용되는지"를 명시한다.

### 4.5 해지 (FR-31)

- 앱 내에서 해지를 직접 처리할 수 없다(스토어 구독). **스토어 구독 관리 화면으로 딥링크**한다.
  - iOS: `itms-apps://apps.apple.com/account/subscriptions`
  - Android: `https://play.google.com/store/account/subscriptions?sku=...&package=...`
- 해지 후에도 **`expires_at`까지 혜택을 유지**한다(FR-31). 만료 시점에 서버 알림으로 `tier = free` 전환.
- 만료 시 처리:
  - 오프라인 저장분 재생 차단(FR-26)
  - 라이브러리 콘텐츠는 삭제하지 않는다. 다만 무료 재생 한도(2편)가 적용된다
  - 드립 편성 중단

### 4.6 구매 복원

- 설정 > 구독 관리 > [구매 복원], 페이월에도 복원 링크 노출(스토어 심사 요건)
- 스토어의 활성 구독을 조회해 서버에서 재검증 후 현재 계정에 연결
- **다른 계정에 이미 연결된 스토어 구독**: 기존 연결을 해제하지 않고 "이미 다른 계정에서 사용 중인 구독이에요" 안내(구독 공유 어뷰징 방지)

### 4.7 환불·결제 실패

- 환불 알림 수신 → 즉시 `tier = free` 전환, 오프라인 저장분 재생 차단
- 갱신 결제 실패(유예 기간, billing retry): 스토어 유예 기간 동안 혜택 유지, 앱 내 배너로 결제 수단 확인 안내

## 5. 화면 상태

**요금제 목록 / 구독 관리 화면**

| 상태 | 화면 |
|---|---|
| 로딩 | 스켈레톤 |
| 미구독 | 3티어 비교 카드 + 각 [구독하기] + [구매 복원] + 약관·자동갱신 안내 |
| 구독 중 | 현재 티어 / 다음 결제일 / 금액 + [요금제 변경] + [구독 해지](스토어 이동) |
| 해지 예약됨 | "N월 N일까지 이용 가능해요" + [구독 다시 시작] |
| 유예 기간(결제 실패) | 경고 배너 + [결제 수단 확인](스토어 이동) |
| 만료됨 | 미구독 상태와 동일 + "구독이 종료되었어요" 안내 |
| 상품 조회 실패 | "요금제를 불러올 수 없어요" + [다시 시도] |
| 결제 진행 중 | 전체 로딩, 화면 이탈 차단 |
| 영수증 검증 중 | "구독을 확인하고 있어요" |
| 검증 실패(일시) | "잠시 후 자동으로 반영됩니다" + 재시도 큐 적재 |
| 결제 취소 | 원래 화면 유지, 에러 문구 없음 |
| 복원 성공 | 토스트 "구독이 복원되었어요" + 상태 갱신 |
| 복원 결과 없음 | "복원할 구독이 없어요" |

**스토어 정책상 필수 표기**: 자동 갱신 조건, 갱신 시점, 해지 방법, 가격·기간, 약관·개인정보처리방침 링크

## 6. 데이터 모델

```
Plan {
  plan_id, tier: enum(light|daily|pro), name, description,
  daily_play_limit: int | null,
  drip_enabled, ads_enabled, offline_download_enabled: boolean,
  price_krw: int,
  store_product_id_ios, store_product_id_android,
  display_order, is_active
}

Subscription {
  subscription_id, user_id,
  tier: enum(light|daily|pro),
  store: enum(app_store|play_store),
  original_transaction_id: string     // 유니크 — 계정 간 중복 연결 방지
  latest_receipt: text
  status: enum(active|grace|cancelled|expired|refunded)
  auto_renew: boolean
  started_at, expires_at, cancelled_at, updated_at
}

PurchaseIntent {
  intent_id (멱등키), user_id, plan_id, platform,
  status: enum(created|verified|failed), created_at
}

StoreNotificationLog {
  notification_id, store, type, payload, processed_at
}

User { tier, entitlements_cache }
```

## 7. 예외 상황

- **영수증 검증 API 장애**: 결제는 이미 완료된 상태다. 티어를 부여하지 않고 실패로 두면 안 된다. 영수증을 큐에 적재해 재시도하고, 사용자에게는 "반영 중"으로 안내한다. 스토어 트랜잭션은 검증 성공 전까지 `finish`하지 않아 재시도가 가능하게 한다.
- **같은 스토어 구독을 다른 계정에서 복원 시도**: `original_transaction_id` 유니크 제약으로 거부하고 안내한다.
- **결제 완료 직후 앱 강제 종료**: 다음 실행 시 미완료 트랜잭션을 조회해 검증한다(SDK의 pending transaction 처리).
- **환불 후에도 앱이 유료 상태**: S2S 알림 수신 시점에 즉시 전환. 알림 유실 대비로 앱 실행 시 동기화에서도 만료·환불을 확인한다.
- **가족 공유·프로모션 코드**: MVP 범위에서 별도 처리하지 않되, 스토어가 유효 구독으로 반환하면 그대로 인정한다.
- **국가·통화 차이**: 가격은 항상 스토어 SDK가 반환한 현지 표기를 노출한다. 서버의 `price_krw`는 참고값이다.
- **요금제가 비활성화(is_active=false)된 뒤 기존 구독자**: 기존 구독은 만료까지 유지하고, 신규 구매 목록에서만 제외한다.
- **다운그레이드 예약 상태에서 다시 업그레이드**: 스토어 상태를 따르고 서버는 S2S 알림으로 최종 상태를 반영한다.
- **탈퇴 후 재가입 시 활성 구독 존재**: 구매 복원으로 새 계정에 연결한다(auth 명세 참조).
- **유예 기간 중 재생 한도**: 혜택을 유지한다(무료로 강등하지 않는다).

## 8. 완료 조건

- Given 무료 사용자 / When 데일리 요금제를 결제 완료한다 / Then 서버 영수증 검증 후 티어가 즉시 데일리로 반영되고 재생 한도가 확장된다
- Given 결제는 성공했으나 서버 검증이 일시 실패했다 / When 잠시 후 재시도가 수행된다 / Then 티어가 자동으로 반영되고 사용자가 재결제할 필요가 없다
- Given 프로 구독 중인 사용자 / When 스토어에서 구독을 해지한다 / Then 만료일까지는 프로 혜택이 유지된다
- Given 구독 만료일이 지났다 / When 앱을 실행한다 / Then 티어가 무료로 전환되고 하루 2편 제한이 적용된다
- Given 구독 만료 상태 / When 오프라인 저장분을 재생 시도한다 / Then 재생이 차단된다
- Given 앱을 재설치한 유료 사용자 / When [구매 복원]을 누른다 / Then 활성 구독이 검증되어 티어가 복원된다
- Given 다른 계정에 연결된 스토어 구독 / When 복원을 시도한다 / Then 거부되고 안내 문구가 노출된다
- Given 환불이 처리되었다 / When 스토어 알림이 수신된다 / Then 즉시 무료 티어로 전환된다
- Given 라이트에서 프로로 업그레이드한다 / When 결제가 완료된다 / Then 즉시 프로 혜택이 적용된다
- Given 프로에서 라이트로 다운그레이드한다 / When 결제 주기가 만료된다 / Then 그 시점부터 라이트 혜택이 적용된다

## 미결 사항

- **티어 명칭·구성 불일치**: PRD 4.1(무료/베이직/프로) vs FR-28(라이트/데일리/프로). 확정 필요
- 티어별 일 청취 편수·가격 — 1~2주 시범 운영 후 결정(PRD 4.1)
- **라이트·데일리 티어의 오프라인 저장 허용 여부** — FR-26은 "유료 전용"이라고만 정의
- 무료 체험(free trial) 제공 여부 및 기간
- 프로 티어의 "월 팩 크레딧 1개"(PRD 4.2)는 MVP 비범위 — 도입 시 본 명세 개정 필요
